prompt PL/SQL Developer Export Tables for user C##BUPA@LOCALHOST/ORCL
prompt Created by Administrator on 14 �ubat 2022 Pazartesi
set feedback off
set define off

prompt Creating CUSTOMERS...
create table CUSTOMERS
(
  customer_id INTEGER not null,
  firstname   NVARCHAR2(150) not null,
  surname     NVARCHAR2(50),
  job         NVARCHAR2(40),
  adress      VARCHAR2(60),
  city        VARCHAR2(30),
  postal_code NVARCHAR2(10),
  phone       VARCHAR2(20),
  card_name   VARCHAR2(20),
  card_number VARCHAR2(20),
  expiration  VARCHAR2(20),
  cvv         VARCHAR2(20),
  taksit      VARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table CUSTOMERS
  add constraint PK_CUSTOMERS_CUSTOMER_ID primary key (CUSTOMER_ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Creating ORDERS...
create table ORDERS
(
  order_id    INTEGER not null,
  customer_id INTEGER not null,
  order_date  NVARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column ORDERS.order_date
  is 'siparis tarihi';
alter table ORDERS
  add constraint PK_ORDERS_ORDER_ID primary key (ORDER_ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table ORDERS
  add constraint FK_ORDERS_CUSTOMER_ID foreign key (CUSTOMER_ID)
  references CUSTOMERS (CUSTOMER_ID) on delete cascade;

prompt Creating PRODUCTS...
create table PRODUCTS
(
  product_id   INTEGER not null,
  product_name VARCHAR2(40) not null,
  price        INTEGER,
  description  VARCHAR2(90)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table PRODUCTS
  add constraint PK_PRODUCTS_PRODUCT_ID primary key (PRODUCT_ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );

prompt Creating ORDER_DETAILS...
create table ORDER_DETAILS
(
  order_id   INTEGER not null,
  product_id INTEGER not null,
  price      NVARCHAR2(20)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table ORDER_DETAILS
  add constraint FK_ORDER_DETAILS_ORDER_ID foreign key (ORDER_ID)
  references ORDERS (ORDER_ID) on delete cascade;
alter table ORDER_DETAILS
  add constraint FK_ORDER_DETAILS_PRODUCT_ID foreign key (PRODUCT_ID)
  references PRODUCTS (PRODUCT_ID) on delete cascade;

prompt Disabling triggers for CUSTOMERS...
alter table CUSTOMERS disable all triggers;
prompt Disabling triggers for ORDERS...
alter table ORDERS disable all triggers;
prompt Disabling triggers for PRODUCTS...
alter table PRODUCTS disable all triggers;
prompt Disabling triggers for ORDER_DETAILS...
alter table ORDER_DETAILS disable all triggers;
prompt Disabling foreign key constraints for ORDERS...
alter table ORDERS disable constraint FK_ORDERS_CUSTOMER_ID;
prompt Disabling foreign key constraints for ORDER_DETAILS...
alter table ORDER_DETAILS disable constraint FK_ORDER_DETAILS_ORDER_ID;
alter table ORDER_DETAILS disable constraint FK_ORDER_DETAILS_PRODUCT_ID;
prompt Loading CUSTOMERS...
insert into CUSTOMERS (customer_id, firstname, surname, job, adress, city, postal_code, phone, card_name, card_number, expiration, cvv, taksit)
values (418, 'emine', 'acar', 'sad', 'dasd', '?zmir', '434', '3434', 'emine acar', '34343434343343', '23/22', '233', '3');
insert into CUSTOMERS (customer_id, firstname, surname, job, adress, city, postal_code, phone, card_name, card_number, expiration, cvv, taksit)
values (419, 'ahmet', 'demir', 'asdasd', 'asdasd', '?zmir', '334', '343443', 'ahmet demir', '34343 34 343 43 34 ', '22', '233', '3');
insert into CUSTOMERS (customer_id, firstname, surname, job, adress, city, postal_code, phone, card_name, card_number, expiration, cvv, taksit)
values (409, '�afak', 'hoca', 'sdsd', 'sdsd', '?zmir', '343', '343', '434', '34', '34', '34', '3');
insert into CUSTOMERS (customer_id, firstname, surname, job, adress, city, postal_code, phone, card_name, card_number, expiration, cvv, taksit)
values (410, 'ba�ak', 'ba�ak', 'hj', 'h', '?zmir', '4545', '4545', 'dsffdd', '4545', '454', '45', '3');
insert into CUSTOMERS (customer_id, firstname, surname, job, adress, city, postal_code, phone, card_name, card_number, expiration, cvv, taksit)
values (412, 'p�rasa', 'p�rasa', 'p�rasa', 'saddsad', '?zmir', 'sad', '3434', 'sdasd', '454545', '454', '45', '3');
insert into CUSTOMERS (customer_id, firstname, surname, job, adress, city, postal_code, phone, card_name, card_number, expiration, cvv, taksit)
values (415, 'ffff', 'ff', 'ff', 'ff', 'f', 'ff', 'strffing', 'sdsd', '4545', '454', '444', '3');
insert into CUSTOMERS (customer_id, firstname, surname, job, adress, city, postal_code, phone, card_name, card_number, expiration, cvv, taksit)
values (416, 'ffff', 'ff', 'ff', 'ff', 'f', 'ff', 'strffing', 'sdsd', '4545', '454', '444', '3');
commit;
prompt 7 records loaded
prompt Loading ORDERS...
insert into ORDERS (order_id, customer_id, order_date)
values (88, 418, '14-�ub-2022');
insert into ORDERS (order_id, customer_id, order_date)
values (82, 409, '12-�ub-2022');
insert into ORDERS (order_id, customer_id, order_date)
values (83, 410, '12-�ub-2022');
insert into ORDERS (order_id, customer_id, order_date)
values (85, 412, '12-�ub-2022');
insert into ORDERS (order_id, customer_id, order_date)
values (89, 419, '14-�ub-2022');
commit;
prompt 5 records loaded
prompt Loading PRODUCTS...
insert into PRODUCTS (product_id, product_name, price, description)
values (1, 'Ayakta tedavi', 500, 'ayakta tedavi aciklama');
insert into PRODUCTS (product_id, product_name, price, description)
values (2, 'yatarak tedavi', 1000, 'yatarak tedavi aciklamasi');
insert into PRODUCTS (product_id, product_name, price, description)
values (3, 'ayatak ve yatarak tedavi', 1500, 'ayakta ve yatarak tedavi aciklamasi');
commit;
prompt 3 records loaded
prompt Loading ORDER_DETAILS...
insert into ORDER_DETAILS (order_id, product_id, price)
values (89, 1, '500 ');
insert into ORDER_DETAILS (order_id, product_id, price)
values (82, 1, '500');
insert into ORDER_DETAILS (order_id, product_id, price)
values (83, 1, '500');
insert into ORDER_DETAILS (order_id, product_id, price)
values (85, 1, '500');
insert into ORDER_DETAILS (order_id, product_id, price)
values (88, 1, '500 ');
commit;
prompt 5 records loaded
prompt Enabling foreign key constraints for ORDERS...
alter table ORDERS enable constraint FK_ORDERS_CUSTOMER_ID;
prompt Enabling foreign key constraints for ORDER_DETAILS...
alter table ORDER_DETAILS enable constraint FK_ORDER_DETAILS_ORDER_ID;
alter table ORDER_DETAILS enable constraint FK_ORDER_DETAILS_PRODUCT_ID;
prompt Enabling triggers for CUSTOMERS...
alter table CUSTOMERS enable all triggers;
prompt Enabling triggers for ORDERS...
alter table ORDERS enable all triggers;
prompt Enabling triggers for PRODUCTS...
alter table PRODUCTS enable all triggers;
prompt Enabling triggers for ORDER_DETAILS...
alter table ORDER_DETAILS enable all triggers;

set feedback on
set define on
prompt Done
